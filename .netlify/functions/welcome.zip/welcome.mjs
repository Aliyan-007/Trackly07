
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/welcome.mjs
var welcome_default = async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const key = process.env.RESEND_API_KEY, from = process.env.RESEND_FROM;
  if (!key || !from) return Response.json({ skipped: true });
  const { email, name } = await req.json();
  const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" }, body: JSON.stringify({ from, to: [email], subject: "Welcome to Trackly", html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto"><h1>Welcome to Trackly, ${name || "there"}.</h1><p>Your calmer academic workspace is ready. Plan one small thing, then begin.</p></div>` }) });
  if (!response.ok) return Response.json({ error: "Could not send welcome email." }, { status: 500 });
  return Response.json({ sent: true });
};
export {
  welcome_default as default
};
